function [ theta, d, ell, m ] = dualq2screw( x )

Sr = x(1);
Vr = x(2:4);	

Sd = x(5);
Vd = x(6:8);	

theta = 2*acos( Sr );

eps_theta = 0.0001; % 0.005 degree

if(abs(theta) > eps_theta && abs(theta) < (2*pi - eps_theta)) 

    ell = Vr/norm(Vr);
    d = -Sd*(2/norm(Vr));
    m = (Vd - Sr*0.5*d*ell)/norm(Vr);

else

    qrr = x(1:4);
    qdd = x(5:8);

    t = 2*mulpq( qdd, conjq( qrr ) );
    t = t(2:4);
    
    d = norm(t);
    ell = t/d;
    m = [0;0;0];
    
end

