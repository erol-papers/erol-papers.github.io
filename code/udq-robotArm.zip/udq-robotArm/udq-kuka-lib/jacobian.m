function J = jacobian( q )
% q : is a vector of joint angles in radian
% x : is the end-effector pose

 d_offset = 1.215;
 
 p0 = [0; 0; -d_offset];
 
 theta1 = q(1);
 u1 = [ 0; 0; 1 ];
 p1 =  [ 0; 0; 0.11 - d_offset ];
 x1 = screw2dq( theta1, u1, 0,  cross( p1, u1 ) );
   
 theta2 = q(2);
 u2 = [ 0; -1; 0 ];
 p2 =  [ 0; 0; 0.3105 - d_offset ];
 x2 = screw2dq( theta2, u2, 0,  cross( p2, u2 ) );
  
 theta3 = q(3);
 u3 = [ 0; 0; 1 ];
 p3 =  [ 0; 0; 0.51 - d_offset ];
 x3 = screw2dq( theta3, u3, 0,  cross( p3, u3 ) );
 
 
 theta4 = q(4);
 u4 = [ 0; 1; 0 ];
 p4 =  [ 0; 0; 0.7105 - d_offset ];
 x4 = screw2dq( theta4, u4, 0,  cross( p4, u4 ) );
 
 
 
 theta5 = q(5);
 u5 = [ 0; 0; 1 ];
 p5 =  [ 0; 0; 0.91 - d_offset ];
 x5 = screw2dq( theta5, u5, 0,  cross( p5, u5 ) );
 
 
 
 theta6 = q(6);
 u6 = [ 0; -1; 0 ];
 p6 =  [ 0; 0; 1.105 - d_offset ];
 x6 = screw2dq( theta6, u6, 0,  cross( p6, u6 ) );
 
 
 theta7 = q(7);
 u7 = [ 0; 0; 1 ];
 p7 =  [ 0; 0; 1.1785 - d_offset ];
 x7 = screw2dq( theta7, u7, 0,  cross( p7, u7) );
  
 pe = [ 0; 0; 0];
 
 
 
 x01 = x1;
 x02 = muldualpq( x01, x2 );
 x03 = muldualpq( x02, x3 );
 x04 = muldualpq( x03, x4 );
 x05 = muldualpq( x04, x5 );
 x06 = muldualpq( x05, x6 );
 x07 = muldualpq( x06, x7 );
  

 %%  Kuka robot nodes %%%%%%%%%%%%%

 u1 = u1;
 p1 = p1; 
 
 
 x = x01;
 axe_2 = [ 0; u2; 0; cross(p2, u2) ];
 axe_2 = muldualpq( muldualpq( x, axe_2 ),  conjdualqsimple(x) );
 u2 = axe_2(2:4);
 p2 = [ 1; zeros(4,1); p2 ];
 p2 = muldualpq( muldualpq( x, p2 ),  conjdualq(x) );
 p2 = p2(6:8);
  
 
 x = x02;
 axe_3 = [ 0; u3; 0; cross(p3, u3) ];
 axe_3 = muldualpq( muldualpq( x, axe_3 ),  conjdualqsimple(x) );
 u3 = axe_3(2:4);
 p3 = [ 1; zeros(4,1); p3 ];
 p3 = muldualpq( muldualpq( x, p3 ),  conjdualq(x) );
 p3 = p3(6:8);
 
 
 x = x03;
 axe_4 = [ 0; u4; 0; cross(p4, u4) ];
 axe_4 = muldualpq( muldualpq( x, axe_4 ),  conjdualqsimple(x) );
 u4 = axe_4(2:4);
 p4 = [ 1; zeros(4,1); p4 ];
 p4 = muldualpq( muldualpq( x, p4 ),  conjdualq(x) );
 p4 = p4(6:8);
 
 
 x = x04;
 axe_5 = [ 0; u5; 0; cross(p5, u5) ];
 axe_5 = muldualpq( muldualpq( x, axe_5 ),  conjdualqsimple(x) );
 u5 = axe_5(2:4);
 p5 = [ 1; zeros(4,1); p5 ];
 p5 = muldualpq( muldualpq( x, p5 ),  conjdualq(x) );
 p5 = p5(6:8);
 
 
 
 x = x05;
 axe_6 = [ 0; u6; 0; cross(p6, u6) ];
 axe_6 = muldualpq( muldualpq( x, axe_6 ),  conjdualqsimple(x) );
 u6 = axe_6(2:4);
 p6 = [ 1; zeros(4,1); p6 ];
 p6 = muldualpq( muldualpq( x, p6 ),  conjdualq(x) );
 p6 = p6(6:8);
  
 
 
 x = x06;
 axe_7 = [ 0; u7; 0; cross(p7, u7) ];
 axe_7 = muldualpq( muldualpq( x, axe_7 ),  conjdualqsimple(x) );
 u7 = axe_7(2:4);
 p7 = [ 1; zeros(4,1); p7 ];
 p7 = muldualpq( muldualpq( x, p7 ),  conjdualq(x) );
 p7 = p7(6:8);
 
 
 x = x07;
 pe = [ 1; zeros(4,1); pe ];
 pe = muldualpq( muldualpq( x, pe ),  conjdualq(x) );
 pe = pe(6:8);
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 v1 = p1 - pe;
 j1 = [ cross( v1, u1 );  u1 ]; 
 
 
 v2 = p2 - pe;
 j2 = [ cross( v2, u2 );  u2 ]; 
 
 
 v3 = p3 - pe;
 j3 = [ cross( v3, u3 );  u3 ];
 
 v4 = p4 - pe;
 j4 = [ cross( v4, u4 );  u4 ];
 
 
 v5 = p5 - pe;
 j5 = [ cross( v5, u5 );  u5 ];
 
 
 v6 = p6 - pe;
 j6 = [ cross( v6, u6 );  u6 ]; 
 
 v7 = p7 - pe;
 j7 = [ cross( v7, u7 );  u7 ]; 
 
  
 J = [ j1, j2, j3, j4, j5, j6, j7 ];
  
  
    
       
       
       
       
       
       
       
       
       
       
       
       
       
    