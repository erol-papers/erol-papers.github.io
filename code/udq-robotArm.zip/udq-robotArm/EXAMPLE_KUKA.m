%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Free Licence
% ------------ 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
% Citing
% ------
% Kinematic Modeling and Control of a Robot Arm using Unit Dual Quaternions
% Robotics and Autonomous Systems, Vol. 77, pp. 66-73, 2016.   
% Erol Ozgur, Youcef Mezouar.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath('./udq-kuka-lib'); 
clear; clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
deg2rad = pi/180;

HOMEq = zeros(7,1); % chosen home configuration for easy modeling purposes.
d_offset = 1.215;  % base frame placed to the tip of the end-effector at home configuration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial joint configuration for the Kuka
q = [ 0*deg2rad; 0*deg2rad; 0*deg2rad; 0*deg2rad; 0*deg2rad; 0*deg2rad; 0*deg2rad ];
x = fkm ( q ); % forward position kinematics returns a unit dual quaternion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Desired Cartesian pose for the Kuka
u = rand(3,1);  
u = u/norm(u);
theta = -60*deg2rad;
t = [ 0.3; 0.5; -0.4 ];
x_offset = uthetat2dq( u, theta, t );
x_desired = muldualpq( x_offset, x );
pose_desired = dualq2pose44( x_desired );  % used for visualization

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
traces = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% simulation parameters
time = 0;  % current time
tf = 3; % final time (seconds) 
dt = 0.002; % control sampling time

figure; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
while( time < tf )

[ x, kuka_wire ] = fkm_visual( q );  % x = fkm ( q );
[ u, theta, R, t ] = dualq2uthetaRt( x );  % used for visualization
pose = dualq2pose44( x );  % used for visualization
J = jacobian( q ); % robot arm jacobian 

x_e = muldualpq( x, conjdualqsimple( x_desired ) ); % compute the error
[ theta_e, d_e, ell_e, m_e ] = dualq2screw( x_e ); % decompose dual quaternion to its dual angle and motion screw axis (natural logarithm)

% velocity screw from error
v = theta_e*m_e + d_e*ell_e;
w = theta_e*ell_e; 

% control law
k = 2; % control gain
mu = 0.0001; % damped Jacobian parameter
A = J'*J + mu*eye(7);
control_law_joint = -k*inv( A )*J'*[ v; w ]; % joint velocities


% simulation update for state of the robot arm
q = q + dt*control_law_joint;  % update Kuka robot (for visual simulation)
time = time + dt;  % (for visual simulation)

% visualisation of the robot motion
traces = [ traces, t ]; % trace the trajectory of the robot  
hold on; clf;
plot3( traces(1,:), traces(2,:), traces(3,:), 'k' );
plot_kuka( kuka_wire, q, 0 ); 
plot_pose( pose, 'g' );
plot_pose( pose_desired, 'b' );
axis([-1.2 1.2 -1.2 1.2  -1.3 0]);
view( 60, 20 ); 
title( [num2str(time), ' seconds'] );
drawnow;

end
